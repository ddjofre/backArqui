#!/bin/bash

echo "=== Verificando configuración cross-region ==="
echo ""

# 1. Verificar región de la instancia
echo "1. Región de esta instancia EC2:"
TOKEN=$(curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" 2>/dev/null)
REGION=$(curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/region 2>/dev/null)
echo "   Región: $REGION"
echo ""

# 2. Verificar credenciales AWS
echo "2. Verificando credenciales AWS:"
aws sts get-caller-identity
echo ""

# 3. Verificar acceso a ECR público en us-east-1
echo "3. Verificando acceso a ECR público (us-east-1):"
aws ecr-public describe-registries --region us-east-1
if [ $? -eq 0 ]; then
    echo "   ✓ Acceso a ECR público confirmado"
else
    echo "   ✗ ERROR: No se puede acceder a ECR público"
fi
echo ""

# 4. Verificar acceso al bucket S3
echo "4. Verificando acceso al bucket S3:"
aws s3 ls s3://backend-grupo18/ --region us-east-2
if [ $? -eq 0 ]; then
    echo "   ✓ Acceso al bucket confirmado"
else
    echo "   ✗ ERROR: No se puede acceder al bucket"
fi
echo ""

# 5. Verificar login en ECR
echo "5. Intentando login en ECR público:"
aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws/d5g5l5p3
if [ $? -eq 0 ]; then
    echo "   ✓ Login exitoso en ECR"
else
    echo "   ✗ ERROR: No se pudo hacer login en ECR"
fi
echo ""

# 6. Verificar pull de imagen
echo "6. Intentando pull de una imagen de prueba:"
docker pull public.ecr.aws/d5g5l5p3/iic2173_grupo18_backend:api-latest
if [ $? -eq 0 ]; then
    echo "   ✓ Pull de imagen exitoso"
    docker images | grep iic2173_grupo18_backend
else
    echo "   ✗ ERROR: No se pudo hacer pull de la imagen"
fi
echo ""

echo "=== Verificación completada ==="