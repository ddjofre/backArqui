#!/bin/bash

echo "Pulling aplication"
cd /home/ubuntu/
docker compose --file docker-compose.production.yml pull